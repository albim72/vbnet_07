﻿Module Module1

    Sub Main()

        Try
            Dim x As Integer = 0
            x = Int(InputBox("Podaj wartość x", "wartość x"))
            Dim y As Double = 1 / x

            Console.WriteLine($"wartość y = {y}")
            Console.WriteLine($"pierwiastek z y: {Math.Sqrt(y)}")
        Catch ex As DivideByZeroException
            Console.WriteLine($"dzielenie przez 0: {ex.Message}")
            Exit Sub
        Finally
            MsgBox("Kod wykonany w każdym przypadku!")

        End Try


        Console.ReadKey()

    End Sub

End Module
