﻿Module Module1

    Sub Main()

        Dim miasto As String
        Dim Miasta(5) As String
        Miasta(0) = "Londyn"
        Miasta(1) = "Rzym"
        Miasta(2) = "Paryż"
        Miasta(3) = "Tokyo"
        Miasta(4) = "Nowy Jork"
        Miasta(5) = "Oslo"
        For Each miasto In Miasta
            MsgBox(miasto)
        Next
        Dim citynumS As String
        Dim citynum As Long
        citynumS = InputBox("Ile miast chcesz wpisać?", "liczba miast")
        citynum = CLng(citynumS)
        Dim cities() As String
        ReDim cities(citynum)
        For i = 1 To citynum
            cities(i) = InputBox("podaj nazwę miasta")
            'MsgBox(cities(i))
        Next
        Dim cit As String
        'Dim zbior As String

        For Each cit In cities
            Console.WriteLine(cit)
        Next

        Console.ReadKey()

    End Sub

End Module
