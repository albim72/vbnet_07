﻿Module Module1


    'napisz funckję, która będzie zwracała datę ważności produktu kosmetycznego:
    'funckcja oparta na parametrach data_otwarcia, oznaczenie
    'ważność produktu licz się od daty otwarcia w zależności od rodzaju oznaczenia na pudełku
    ' oznaczenia:
    '1M  - 30 dni, 3M  - 90 dni, 6M  -180 dni, 1R - 365 dni, 3L - 1095 dni

    'zaimplememntuj funkcję w main() -> podaj z inputbox -> data_otwarcia, oznaczenie na pudełku
    'wywołaj fukcję -> wyświetl datę przydatności


    Function data_w(data_otw, okr_w)
        'data_w - data ważności produktu
        data_w = "nieznana"
        Select Case okr_w
            Case Is = "1M" : data_w = DateAdd("d", 30, data_otw)
            Case Is = "3M" : data_w = DateAdd("d", 90, data_otw)
            Case Is = "6M" : data_w = DateAdd("d", 180, data_otw)
            Case Is = "1R" : data_w = DateAdd("d", 365, data_otw)
            Case Is = "3L" : data_w = DateAdd("d", 1095, data_otw)
        End Select
    End Function
    Sub Main()
        Dim data_ot As Date
        Dim okres_w As String
        Dim data_waz
        data_ot = InputBox("Podaj datę otwarcia produktu")
        okres_w = InputBox("Podaj oznaczenie na kosmetyku")
        data_waz = data_w(data_ot, okres_w)
        'data_w_konwert = CDate(data_waz)
        Console.WriteLine("data ważności kosmetyku: " & data_waz)
        Console.ReadKey()
        MsgBox("data ważności kosmetyku: " & data_waz)
    End Sub

End Module
