﻿Module Module1


    Function funckcja_z_bledem(a, x)
        If x < 0 Then
            Return "x musi być większe lub równe 0"
            Exit Function
        End If

        If a = x Then
            Return "nieskończność....."
        Else
            Return (a * x + Math.Sqrt(x) / (a - x))
        End If
    End Function

    Sub Main()
        Dim x, a As Single
        Dim xss, ass As String
        Dim y As Object

        xss = InputBox("Podaj wartość x: ", "wartość x")
        ass = InputBox("Podaj wartość a: ", "wartość a")

        x = CSng(xss)
        a = CSng(ass)

        y = funckcja_z_bledem(a, x)
        Console.WriteLine($"wynik działania funkcji: {y}")
        Console.ReadKey()

    End Sub

End Module
