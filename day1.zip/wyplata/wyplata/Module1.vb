﻿Module Module1

    Sub Main()
        'podaj wyskość kwoty brutto do wypłaty (inputbox)
        'przelicz kwotę na kwotę do wypłaty (netto) która będzie wynosiła 73% kwoty brutto
        'wyświetl wynik w dwóch postaciach: msgbox i konsola
        'zastanów się jak zareagować na błędnie podaną wartość kwoty brutto??

        Dim s As String
        Dim wBrutto, wNetto As Long
        s = InputBox("Podaj wysokość wypłaty brutto", "wypłata brutto")

        If IsNumeric(s) Then
            wBrutto = s
            wNetto = 0.73 * wBrutto
            MsgBox("Wypłata brutto wynosi: " & wBrutto _
                   & ", wypłata netto: " & wNetto)
        Else
            MsgBox("Nieprawidłowa wartość wypłaty, musi być liczbą")
        End If



    End Sub

End Module
