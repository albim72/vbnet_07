﻿Module Module1

    Sub Main()
        Dim k1 As Kolor = New Kolor(34, "niebieski")
        k1.printKolor()

        Dim k2 As Kolor = New Kolor(113, "burgund")
        k2.nazwa_palety = "Paleta C"
        k2.imie = "George"
        k2.nazwisko = "Hit"
        k2.printKolor()

        Console.ReadKey()
    End Sub

End Module
