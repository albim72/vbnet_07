﻿Module Module1

    Sub Numer(x As Integer)
        Dim y As Integer = 2 * x + 3
        Console.WriteLine(y)
    End Sub

    Function osoba(imie, nazwisko)
        Console.Write("numer uczestnika:")
        Numer(9)
        Return $"uczestnik konferencji: {imie} {nazwisko}"

    End Function

    Sub Informacja()
        Console.WriteLine("Konferencja - wdrożenie wybranych algorytmów AI")
        Console.WriteLine($"Informacja - {osoba("Jan", "Nowak")}")
    End Sub


    Sub Main()
        Informacja()
        Console.ReadKey()
    End Sub

End Module
