﻿Module Module1

    Sub Main()

        'pętla do Until
        Dim x = 0, y
        Do Until x = 11
            x = x + 1
            y = 2 * x
            Console.WriteLine($"wartość y = {y}")
        Loop

        Console.WriteLine("++++++++++++++++++++++++++++++++++")

        'pętla while

        Dim g = 4
        While g < 36
            g = 3 * g
            Console.WriteLine($"wartość g = {g}")
        End While
        Console.WriteLine($"wartość końcowa g = {g}")

        Console.WriteLine("++++++++++++++++++++++++++++++++++")
        'petla for
        'wyświetl wszystkie kombinacje (n,m) gdzie n = 1..4, m = 1..5
        For n = 1 To 4
            For m = 1 To 5
                Console.WriteLine($"para (n,m): ({n},{m})")
            Next
        Next

        Console.ReadKey()
    End Sub

End Module
