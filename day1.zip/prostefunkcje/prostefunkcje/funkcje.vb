﻿Module funkcje

    Function mnozenie(a, b, c)
        mnozenie = a * b * c
    End Function

    Function policz(a As Integer, b As Double, g As Integer, Optional x As Double = 100.1) As Double
        Return (a + b) * x - g
    End Function

    Function info(msg)
        Return $"To jest bradzo ważna wiadomość: {msg}"
    End Function

    Sub Main()
        Dim x As Integer
        x = mnozenie(34, 2, 78)
        Console.WriteLine("Wynik mnożenia = " & x)
        MsgBox("Wynik mnożenia = " & x)

        Console.WriteLine("wynik działania policz() = {0} ", policz(2, 4.2, 6.7, 9))
        MsgBox("wynik działania policz() dla  2 parametrów = " & policz(2, 4.1, 7))

        Console.WriteLine(info("dziś jest promocja na...."))
        MsgBox(info(3456))

        Dim xx = 9
        Dim yy = 99.4
        Dim imie = "Janek"

        Console.WriteLine("Dane ->  imię: {2}, x = {0}, y = {1}", xx, yy, imie)

        Console.ReadKey()

    End Sub

End Module
