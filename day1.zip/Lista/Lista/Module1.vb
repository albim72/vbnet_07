﻿Module Module1

    Sub Main()
        Dim kolory As New List(Of String)
        kolory.Add("czerwony")
        kolory.Add("zielony")
        kolory.Add("czarny")
        kolory.Add("biały")
        kolory.Add("szary")

        For Each kol As String In kolory
            Console.WriteLine(kol)
        Next

        Dim kolory_ini As New List(Of String) From
            {"pomarańczowy", "liliowy", "brązowy", "oliwkowy"}

        For Each kolin As String In kolory_ini
            Console.WriteLine(kolin)
        Next

        kolory_ini.Remove("oliwkowy")

        For index = 0 To kolory_ini.Count - 1
            Console.Write(kolory_ini(index) & " ")
        Next
        Console.ReadKey()
    End Sub

End Module
