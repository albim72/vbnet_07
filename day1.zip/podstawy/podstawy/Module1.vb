﻿Module Module1

    Sub Main()
        Console.WriteLine("Pierwszy program...")
        Dim imie = "Ryszard"
        Dim nazwisko As String = "Kot"
        Dim wiek = 43

        'komentarz - skrót CTRL + D -> powielenie linii
        MsgBox(VarType(imie))
        MsgBox(VarType(nazwisko))
        MsgBox(VarType(wiek))

        'komentowanie bloku CTRL+K, CTRL+C
        'odkomentowanie bloku CTRL+K, CTRL+U

        wiek = 78
        MsgBox(VarType(wiek))

        Dim wiek_d = 56.5

        MsgBox(VarType(wiek_d))
        MsgBox("wiek = " + wiek_d.ToString)


        If wiek = 45 Then
            Console.WriteLine("Osoba ma 45 lat...")
        Else
            Console.WriteLine("Osoba w innym wieku.....")
        End If

        If imie = "Jan" Then
            Console.WriteLine("Cześć Jan")
        End If

        If imie = "Ryszard" Then
            Console.WriteLine("Cześć Ryszard!")
        End If

        If imie = "Ryszard" Then
            If wiek = 78 Then
                Console.WriteLine("Cześć Ryszard, niedługo Twoje 78 urodziny!")
            Else
                Console.WriteLine("Cześć Ryszard, nie masz teraz urodzin!")
            End If
        End If

        Console.ReadKey()
    End Sub

End Module
