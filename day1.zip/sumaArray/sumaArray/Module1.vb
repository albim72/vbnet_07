﻿Module Module1

    Function AddElement(ParamArray arr As Integer()) As Integer
        Dim suma As Integer = 0
        Dim i As Integer = 0

        For Each i In arr
            suma += i
        Next i
        Return suma

    End Function

    Sub Main()
        Dim s As Integer
        s = AddElement(566, 7, 8, 19, 23, 45, 88, 2, 113, 17, 8)
        Console.WriteLine($"suma wartości w tablicy: {s}")
        Console.ReadKey()
    End Sub

End Module
