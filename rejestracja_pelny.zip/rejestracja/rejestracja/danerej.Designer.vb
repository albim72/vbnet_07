﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class danerej
    Inherits System.Windows.Forms.Form

    'Formularz przesłania metodę dispose, aby wyczyścić listę składników.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wymagane przez Projektanta formularzy systemu Windows
    Private components As System.ComponentModel.IContainer

    'UWAGA: następująca procedura jest wymagana przez Projektanta formularzy systemu Windows
    'Możesz to modyfikować, używając Projektanta formularzy systemu Windows. 
    'Nie należy modyfikować za pomocą edytora kodu.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.RejestracjaDataSet = New rejestracja.rejestracjaDataSet()
        Me.OsobaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OsobaTableAdapter = New rejestracja.rejestracjaDataSetTableAdapters.osobaTableAdapter()
        Me.IdosobyDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ImieDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NazwiskoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataurodzeniaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MiastoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TelefonDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RejestracjaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OsobaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label1.Location = New System.Drawing.Point(37, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(205, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Aktualne dane rejestracyjne"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IdosobyDataGridViewTextBoxColumn, Me.ImieDataGridViewTextBoxColumn, Me.NazwiskoDataGridViewTextBoxColumn, Me.DataurodzeniaDataGridViewTextBoxColumn, Me.MiastoDataGridViewTextBoxColumn, Me.TelefonDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.OsobaBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(41, 94)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(715, 278)
        Me.DataGridView1.TabIndex = 1
        '
        'RejestracjaDataSet
        '
        Me.RejestracjaDataSet.DataSetName = "rejestracjaDataSet"
        Me.RejestracjaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'OsobaBindingSource
        '
        Me.OsobaBindingSource.DataMember = "osoba"
        Me.OsobaBindingSource.DataSource = Me.RejestracjaDataSet
        '
        'OsobaTableAdapter
        '
        Me.OsobaTableAdapter.ClearBeforeFill = True
        '
        'IdosobyDataGridViewTextBoxColumn
        '
        Me.IdosobyDataGridViewTextBoxColumn.DataPropertyName = "idosoby"
        Me.IdosobyDataGridViewTextBoxColumn.HeaderText = "idosoby"
        Me.IdosobyDataGridViewTextBoxColumn.Name = "IdosobyDataGridViewTextBoxColumn"
        Me.IdosobyDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ImieDataGridViewTextBoxColumn
        '
        Me.ImieDataGridViewTextBoxColumn.DataPropertyName = "imie"
        Me.ImieDataGridViewTextBoxColumn.HeaderText = "imie"
        Me.ImieDataGridViewTextBoxColumn.Name = "ImieDataGridViewTextBoxColumn"
        '
        'NazwiskoDataGridViewTextBoxColumn
        '
        Me.NazwiskoDataGridViewTextBoxColumn.DataPropertyName = "nazwisko"
        Me.NazwiskoDataGridViewTextBoxColumn.HeaderText = "nazwisko"
        Me.NazwiskoDataGridViewTextBoxColumn.Name = "NazwiskoDataGridViewTextBoxColumn"
        '
        'DataurodzeniaDataGridViewTextBoxColumn
        '
        Me.DataurodzeniaDataGridViewTextBoxColumn.DataPropertyName = "data_urodzenia"
        Me.DataurodzeniaDataGridViewTextBoxColumn.HeaderText = "data_urodzenia"
        Me.DataurodzeniaDataGridViewTextBoxColumn.Name = "DataurodzeniaDataGridViewTextBoxColumn"
        '
        'MiastoDataGridViewTextBoxColumn
        '
        Me.MiastoDataGridViewTextBoxColumn.DataPropertyName = "miasto"
        Me.MiastoDataGridViewTextBoxColumn.HeaderText = "miasto"
        Me.MiastoDataGridViewTextBoxColumn.Name = "MiastoDataGridViewTextBoxColumn"
        '
        'TelefonDataGridViewTextBoxColumn
        '
        Me.TelefonDataGridViewTextBoxColumn.DataPropertyName = "telefon"
        Me.TelefonDataGridViewTextBoxColumn.HeaderText = "telefon"
        Me.TelefonDataGridViewTextBoxColumn.Name = "TelefonDataGridViewTextBoxColumn"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Button1.Location = New System.Drawing.Point(639, 406)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(116, 39)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Zamknij"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'danerej
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "danerej"
        Me.Text = "danerej"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RejestracjaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OsobaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents RejestracjaDataSet As rejestracjaDataSet
    Friend WithEvents OsobaBindingSource As BindingSource
    Friend WithEvents OsobaTableAdapter As rejestracjaDataSetTableAdapters.osobaTableAdapter
    Friend WithEvents IdosobyDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ImieDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NazwiskoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DataurodzeniaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MiastoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TelefonDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
End Class
