﻿Public Class danerej
    Private Sub danerej_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: Ten wiersz kodu wczytuje dane do tabeli 'RejestracjaDataSet.osoba' . Możesz go przenieść lub usunąć.
        Me.OsobaTableAdapter.Fill(Me.RejestracjaDataSet.osoba)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Close()
    End Sub
End Class