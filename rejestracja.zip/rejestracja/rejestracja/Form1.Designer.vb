﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Formularz przesłania metodę dispose, aby wyczyścić listę składników.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wymagane przez Projektanta formularzy systemu Windows
    Private components As System.ComponentModel.IContainer

    'UWAGA: następująca procedura jest wymagana przez Projektanta formularzy systemu Windows
    'Możesz to modyfikować, używając Projektanta formularzy systemu Windows. 
    'Nie należy modyfikować za pomocą edytora kodu.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.l2 = New System.Windows.Forms.Label()
        Me.l3 = New System.Windows.Forms.Label()
        Me.l4 = New System.Windows.Forms.Label()
        Me.tbImie = New System.Windows.Forms.TextBox()
        Me.tbNazwisko = New System.Windows.Forms.TextBox()
        Me.tbData = New System.Windows.Forms.TextBox()
        Me.tbMiasto = New System.Windows.Forms.TextBox()
        Me.tbTel = New System.Windows.Forms.TextBox()
        Me.btnDodaj = New System.Windows.Forms.Button()
        Me.l5 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label1.Location = New System.Drawing.Point(51, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(164, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Rejestracja w serwisie"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label2.Location = New System.Drawing.Point(101, 100)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "imię"
        '
        'l2
        '
        Me.l2.AutoSize = True
        Me.l2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.l2.Location = New System.Drawing.Point(101, 142)
        Me.l2.Name = "l2"
        Me.l2.Size = New System.Drawing.Size(65, 17)
        Me.l2.TabIndex = 2
        Me.l2.Text = "nazwisko"
        '
        'l3
        '
        Me.l3.AutoSize = True
        Me.l3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.l3.Location = New System.Drawing.Point(101, 184)
        Me.l3.Name = "l3"
        Me.l3.Size = New System.Drawing.Size(103, 17)
        Me.l3.TabIndex = 3
        Me.l3.Text = "data urodzenia"
        '
        'l4
        '
        Me.l4.AutoSize = True
        Me.l4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.l4.Location = New System.Drawing.Point(101, 226)
        Me.l4.Name = "l4"
        Me.l4.Size = New System.Drawing.Size(49, 17)
        Me.l4.TabIndex = 4
        Me.l4.Text = "miasto"
        '
        'tbImie
        '
        Me.tbImie.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.tbImie.Location = New System.Drawing.Point(293, 92)
        Me.tbImie.Name = "tbImie"
        Me.tbImie.Size = New System.Drawing.Size(362, 23)
        Me.tbImie.TabIndex = 6
        '
        'tbNazwisko
        '
        Me.tbNazwisko.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.tbNazwisko.Location = New System.Drawing.Point(293, 134)
        Me.tbNazwisko.Name = "tbNazwisko"
        Me.tbNazwisko.Size = New System.Drawing.Size(362, 23)
        Me.tbNazwisko.TabIndex = 7
        '
        'tbData
        '
        Me.tbData.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.tbData.Location = New System.Drawing.Point(293, 176)
        Me.tbData.Name = "tbData"
        Me.tbData.Size = New System.Drawing.Size(362, 23)
        Me.tbData.TabIndex = 8
        '
        'tbMiasto
        '
        Me.tbMiasto.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.tbMiasto.Location = New System.Drawing.Point(293, 218)
        Me.tbMiasto.Name = "tbMiasto"
        Me.tbMiasto.Size = New System.Drawing.Size(362, 23)
        Me.tbMiasto.TabIndex = 9
        '
        'tbTel
        '
        Me.tbTel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.tbTel.Location = New System.Drawing.Point(293, 260)
        Me.tbTel.Name = "tbTel"
        Me.tbTel.Size = New System.Drawing.Size(362, 23)
        Me.tbTel.TabIndex = 10
        '
        'btnDodaj
        '
        Me.btnDodaj.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.btnDodaj.Location = New System.Drawing.Point(104, 319)
        Me.btnDodaj.Name = "btnDodaj"
        Me.btnDodaj.Size = New System.Drawing.Size(551, 32)
        Me.btnDodaj.TabIndex = 11
        Me.btnDodaj.Text = "dodaj do bazy"
        Me.btnDodaj.UseVisualStyleBackColor = True
        '
        'l5
        '
        Me.l5.AutoSize = True
        Me.l5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.l5.Location = New System.Drawing.Point(101, 268)
        Me.l5.Name = "l5"
        Me.l5.Size = New System.Drawing.Size(51, 17)
        Me.l5.TabIndex = 5
        Me.l5.Text = "telefon"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnDodaj)
        Me.Controls.Add(Me.tbTel)
        Me.Controls.Add(Me.tbMiasto)
        Me.Controls.Add(Me.tbData)
        Me.Controls.Add(Me.tbNazwisko)
        Me.Controls.Add(Me.tbImie)
        Me.Controls.Add(Me.l5)
        Me.Controls.Add(Me.l4)
        Me.Controls.Add(Me.l3)
        Me.Controls.Add(Me.l2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "serwis REJ"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents l2 As Label
    Friend WithEvents l3 As Label
    Friend WithEvents l4 As Label
    Friend WithEvents tbImie As TextBox
    Friend WithEvents tbNazwisko As TextBox
    Friend WithEvents tbData As TextBox
    Friend WithEvents tbMiasto As TextBox
    Friend WithEvents tbTel As TextBox
    Friend WithEvents btnDodaj As Button
    Friend WithEvents l5 As Label
End Class
